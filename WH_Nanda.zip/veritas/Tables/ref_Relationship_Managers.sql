CREATE TABLE [veritas].[ref_Relationship_Managers] (
    [RMID]         INT           NULL,
    [Name]         VARCHAR (100) NULL,
    [Title]        VARCHAR (100) NULL,
    [ManagerID]    INT           NULL,
    [Jurisdiction] VARCHAR (50)  NULL,
    [Desk]         VARCHAR (50)  NULL,
    [start_date]   DATE          NULL,
    [end_date]     DATE          NULL,
    [is_active]    BIT           NULL
);


GO