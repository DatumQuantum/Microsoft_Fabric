CREATE TABLE [stg].[New_RM_Roster] (
    [RMID]         INT           NULL,
    [Name]         VARCHAR (100) NULL,
    [Title]        VARCHAR (50)  NULL,
    [ManagerID]    INT           NULL,
    [Jurisdiction] VARCHAR (10)  NULL,
    [Desk]         VARCHAR (50)  NULL
);


GO