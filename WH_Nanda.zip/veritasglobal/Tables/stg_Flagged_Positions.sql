CREATE TABLE [veritasglobal].[stg_Flagged_Positions] (
    [PositionID]         VARCHAR (50) NULL,
    [RMID]               VARCHAR (50) NULL,
    [Asset_Class]        VARCHAR (50) NULL,
    [Notional_Value]     VARCHAR (50) NULL,
    [Currency]           VARCHAR (10) NULL,
    [Flag_Type]          VARCHAR (50) NULL,
    [Status]             VARCHAR (50) NULL,
    [Regulatory_Signoff] BIT          NULL,
    [Settlement_Date]    VARCHAR (50) NULL,
    [Flag_Date]          VARCHAR (50) NULL
);


GO