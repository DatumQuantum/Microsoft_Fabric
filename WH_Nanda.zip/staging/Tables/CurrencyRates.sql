CREATE TABLE [staging].[CurrencyRates] (
    [RateDate]       DATE            NULL,
    [BaseCurrency]   CHAR (3)        NULL,
    [TargetCurrency] CHAR (3)        NULL,
    [RateValue]      DECIMAL (20, 6) NULL
);


GO