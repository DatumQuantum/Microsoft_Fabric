CREATE SCHEMA [veritas]
    AUTHORIZATION [dbo];


GO