CREATE SCHEMA [veritasglobal]
    AUTHORIZATION [dbo];


GO